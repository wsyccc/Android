package lifecycle.comp3717.bcit.ca.lifecycle;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

// http://developer.android.com/reference/android/app/Activity.html
public class MainActivity
   extends AppCompatActivity
{
    private TextView helloField;

    @Override
    protected void onCreate(final Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        helloField = (TextView)findViewById(R.id.helloLabel);
        Log.d("MainActivity", "onCreate");
    }

    @Override
    protected void onStart()
    {
        Log.d("MainActivity", "onStart");
        super.onStart();
    }

    @Override
    protected void onRestart()
    {
        Log.d("MainActivity", "onRestart");
        super.onRestart();
    }

    @Override
    protected void onResume()
    {
        Log.d("MainActivity", "onResume");
        super.onResume();
    }

    @Override
    protected void onPause()
    {
        Log.d("MainActivity", "onPause");
        super.onPause();
    }

    @Override
    protected void onStop()
    {
        Log.d("MainActivity", "onStop");
        super.onStop();
    }

    @Override
    protected void onDestroy()
    {
        Log.d("MainActivity", "onDestroy");
        super.onDestroy();
    }
}
